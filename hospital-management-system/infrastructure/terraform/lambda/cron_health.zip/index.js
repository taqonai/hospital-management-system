      const https = require('https');
      const http = require('http');

      exports.handler = async (event) => {
        const backendUrl = process.env.BACKEND_URL || 'http://localhost:3001';
        const cronApiKey = process.env.CRON_API_KEY || '';
        const snsTopicArn = process.env.SNS_TOPIC_ARN || '';

        const healthUrl = `${backendUrl}/api/v1/no-show/cron-health`;
        const triggerUrl = `${backendUrl}/api/v1/no-show/external-trigger`;

        console.log('Checking cron health at:', healthUrl);

        try {
          // First, try to get health status (requires auth, so we use external trigger instead)
          // Call external trigger which also returns health info
          const result = await makeRequest(triggerUrl, 'POST', {
            'x-cron-api-key': cronApiKey,
            'Content-Type': 'application/json'
          });

          console.log('Health check result:', JSON.stringify(result));

          const isHealthy = result.success && result.data && result.data.success;
          const metricValue = isHealthy ? 1 : 0;

          // Put metric to CloudWatch
          const { CloudWatch } = require('@aws-sdk/client-cloudwatch');
          const cloudwatch = new CloudWatch();

          await cloudwatch.putMetricData({
            Namespace: 'HMS/CronJobs',
            MetricData: [
              {
                MetricName: 'CronHealthStatus',
                Value: metricValue,
                Unit: 'Count',
                Dimensions: [
                  { Name: 'JobName', Value: 'NO_SHOW_CHECK' },
                  { Name: 'Environment', Value: process.env.ENVIRONMENT || 'prod' }
                ]
              },
              {
                MetricName: 'CronExecutionDuration',
                Value: result.data?.duration || 0,
                Unit: 'Milliseconds',
                Dimensions: [
                  { Name: 'JobName', Value: 'NO_SHOW_CHECK' },
                  { Name: 'Environment', Value: process.env.ENVIRONMENT || 'prod' }
                ]
              }
            ]
          });

          console.log('Metrics published successfully');

          return {
            statusCode: 200,
            body: JSON.stringify({
              healthy: isHealthy,
              result: result
            })
          };

        } catch (error) {
          console.error('Health check failed:', error.message);

          // Put failure metric
          const { CloudWatch } = require('@aws-sdk/client-cloudwatch');
          const cloudwatch = new CloudWatch();

          await cloudwatch.putMetricData({
            Namespace: 'HMS/CronJobs',
            MetricData: [
              {
                MetricName: 'CronHealthStatus',
                Value: 0,
                Unit: 'Count',
                Dimensions: [
                  { Name: 'JobName', Value: 'NO_SHOW_CHECK' },
                  { Name: 'Environment', Value: process.env.ENVIRONMENT || 'prod' }
                ]
              }
            ]
          });

          // Send alert via SNS
          if (snsTopicArn) {
            const { SNS } = require('@aws-sdk/client-sns');
            const sns = new SNS();

            await sns.publish({
              TopicArn: snsTopicArn,
              Subject: '[ALERT] HMS Cron Health Check Failed',
              Message: `The HMS cron health check failed.

Error: ${error.message}
Time: ${new Date().toISOString()}
URL: ${healthUrl}

Please check the backend logs and health status.

Dashboard: https://console.aws.amazon.com/cloudwatch/home?region=${process.env.AWS_REGION}#metricsV2:graph=~()
              `
            });
          }

          return {
            statusCode: 500,
            body: JSON.stringify({
              healthy: false,
              error: error.message
            })
          };
        }
      };

      function makeRequest(url, method, headers) {
        return new Promise((resolve, reject) => {
          const parsedUrl = new URL(url);
          const protocol = parsedUrl.protocol === 'https:' ? https : http;

          const options = {
            hostname: parsedUrl.hostname,
            port: parsedUrl.port || (parsedUrl.protocol === 'https:' ? 443 : 80),
            path: parsedUrl.pathname,
            method: method,
            headers: headers,
            timeout: 30000
          };

          const req = protocol.request(options, (res) => {
            let data = '';
            res.on('data', chunk => data += chunk);
            res.on('end', () => {
              try {
                resolve(JSON.parse(data));
              } catch (e) {
                reject(new Error(`Invalid JSON response: ${data}`));
              }
            });
          });

          req.on('error', reject);
          req.on('timeout', () => reject(new Error('Request timeout')));
          req.end();
        });
      }
